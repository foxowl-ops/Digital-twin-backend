"""
Insurance Dashboard API Application Package
"""

__version__ = "1.0.0"
__title__ = "Insurance Dashboard API"
__description__ = "RESTful API for insurance data management"
